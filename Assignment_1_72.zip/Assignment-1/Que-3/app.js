
const readline = require('readline');
const Chatbot = require('./chatbot');

// Initialize the chatbot with a specific domain
const chatbot = new Chatbot('Customer Support');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log('Welcome to the chatbot application!');
console.log('Type "exit" to quit.\n');

const askQuestion = () => {
    rl.question('You: ', (input) => {
        if (input.toLowerCase() === 'exit') {
            console.log('Chatbot: Goodbye!');
            rl.close();
            return;
        }

        const response = chatbot.respond(input);
        console.log(`Chatbot: ${response}\n`);
        askQuestion(); // Ask the next question
    });
};

// Start the conversation
askQuestion();
