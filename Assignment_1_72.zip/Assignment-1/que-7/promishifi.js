
const fs = require('fs');
const util = require('util');

const unlink = util.promisify(fs.unlink);

async function deleteFile(filePath) {
    try {
        await unlink(filePath);
        console.log(`File deleted: ${filePath}`);
    } catch (err) {
        console.error(`Error deleting file: ${err.message}`);
    }
}

const fileToDelete = 'test.txt'; 

fs.writeFileSync(fileToDelete, 'This is a test file.');

deleteFile(fileToDelete);
