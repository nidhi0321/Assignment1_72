
const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const Chatbot = require('./chatbot');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const chatbot = new Chatbot('Customer Support');

app.use(express.static('public'));

wss.on('connection', (ws) => {
    console.log('New client connected');

    ws.on('message', (message) => {
        console.log(`Received: ${message}`);
        const response = chatbot.respond(message);
        ws.send(response);
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is listening on http://localhost:${PORT}`);
});
